table1 = document.getElementById('table1');
table2 = document.getElementById('table2');
var table1Boxes = table1.getElementsByTagName('td');
var table2Boxes = table2.getElementsByTagName('td');
var submit = document.getElementById('submit');
var reset = document.getElementById('reset');
var cheat = document.getElementById('cheat');

// Track when holding down mouse button
var mouseDown = false;
document.onmousedown = function() {
    mouseDown = true;
};
document.onmouseup = function() {
    mouseDown = false;
};

// Drag-select feature
for (var i = 0; i < table1Boxes.length; i++) {
    table1Boxes[i].addEventListener("mouseover", function() {
        if (mouseDown){
            this.classList.toggle("grey");
        }
    });
}

// Click to fill boxes grey
for (i = 0; i < table1Boxes.length; i++) {
    table1Boxes[i].addEventListener("mousedown", function() {
            this.classList.toggle("grey");
    });
}

submit.addEventListener("click", function() {
    showSolutionTable();
});

reset.addEventListener("click", function() {
    resetTable();
});

cheat.addEventListener("click", function() {
    showTable();
});

function showSolutionTable() {
    for (var j = 0; j < table1Boxes.length; j++) {
        if ((table1Boxes[j].classList.value === 'grey' && table2Boxes[j].classList.value !== 'grey') || table1Boxes[j].classList.value !== 'grey' && table2Boxes[j].classList.value === 'grey') {
            return alert('Try again.');
        }
    }
    alert('Nice job!');
    showTable();
    var congrats = document.createElement('P');
    var text = document.createTextNode("gg");
    congrats.appendChild(text);
    document.body.appendChild(congrats);
}

function showTable() {
    if ((table2.style.display === 'none' || table2.style.display === '') ){
        table2.style.display = 'table';
    }
    else {
        table2.style.display = 'none';
    }
}

function resetTable() {
    for (var k = 0; k < table1Boxes.length; k++) {
        table1Boxes[k].classList.value = '';
    }
}